# Normalizes the raw data, so that the clustering tool can be applied later.
# Expected data: a table, values separated by tabulations, in the following
# order:
#	- outgoing internal intensity
#	- incoming internal intensity
#	- outgoing density
#	- incoming density
#	- outgoing external intensity
#	- incoming external intensity
#	- outgoing heterogeneity
#	- incoming heterogeneity
# Infinite values are represented by +Inf or -Inf. NA are not allowed.
#
# version: 1
# Author: Vincent Labatut 06/2013
#
# setwd("~/eclipse/workspaces/Networks/Orleans/")
# setwd("C:/Eclipse/workspaces/Networks/Orleans/")
# source("src/p05-normalize.R")
###############################################################################
library("clusterSim")


###############################################################################
# setup files
###############################################################################
folder.data <- "Data/"	
file.input <- "rolemeasures.raw.txt"	# TODO you can possibly change that


###############################################################################
# load raw data
###############################################################################
start.time <- Sys.time();
cat("[",format(start.time,"%a %d %b %Y %H:%M:%S"),"] Loading raw data...\n",sep="")
	file.data <- paste(folder.data,file.input,sep="")
	x <- as.matrix(read.table(file.data))
end.time <- Sys.time();
total.time <- end.time - start.time;
cat("[",format(end.time,"%a %d %b %Y %H:%M:%S"),"] Load completed in ",total.time,"\n",sep="")


###############################################################################
# normalize data (center & reduce)
###############################################################################
start.time <- Sys.time();
cat("[",format(start.time,"%a %d %b %Y %H:%M:%S"),"] Normalizing data...\n",sep="")
	for(c in 1:ncol(x))
	{	cat("[",format(Sys.time(),"%a %d %b %Y %H:%M:%S"),"] ..Processing col.",c,"\n",sep="")
		
		# get rid of NA (?)
		idx.na <- which(is.na(x[,c]))
		if(length(idx.na)>0)
		{	x[idx.na,c] <- 0
			cat("[",format(Sys.time(),"%a %d %b %Y %H:%M:%S"),"] ....WARNING: ",length(idx.na)," NA values found in the raw data (col.",c,")\n",sep="")
		}
		
		# get rid of infinite values
		idx.inf <- which(is.infinite(x[,c]))
		if(length(idx.inf)>0)
		{	x[idx.inf,c] <- 0
			cat("[",format(Sys.time(),"%a %d %b %Y %H:%M:%S"),"] ....Replacing ",length(idx.inf)," infinite values by 0 in col.",c,")\n",sep="")
		}
		
		# normalize
		average <- mean(x[,c] | x[,c]==1.79769e+308)
		stdev <- sd(x[,c])
		cat("[",format(Sys.time(),"%a %d %b %Y %H:%M:%S"),"] ....Normalizing col.",c,": avg=",average," stdev=",stdev,"\n",sep="")
		x[,c] <- (x[,c] - average) / stdev
	}
end.time <- Sys.time();
total.time <- end.time - start.time;
cat("[",format(end.time,"%a %d %b %Y %H:%M:%S"),"] Normalization completed in ",total.time,"\n",sep="")


###############################################################################
# record normalized data
###############################################################################
start.time <- Sys.time();
cat("[",format(start.time,"%a %d %b %Y %H:%M:%S"),"] Recording normalized data\n",sep="")
	file.norm <- paste(folder.data,"rolemeasures.normalized.txt",sep="")
	write.table(x=x,file=file.norm,row.names=FALSE,col.names=FALSE)
end.time <- Sys.time();
total.time <- end.time - start.time;
cat("[",format(end.time,"%a %d %b %Y %H:%M:%S"),"] Recording completed in ",total.time,"\n",sep="")
